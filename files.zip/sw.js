const CACHE = 'evacuaid-v1';
const ASSETS = [
  '/evacuAID/',
  '/evacuAID/index.html',
  '/evacuAID/manifest.json'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(ASSETS))
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request))
  );
});
